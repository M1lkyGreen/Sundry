/*
Navicat MySQL Data Transfer

Source Server         : yx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : water

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2023-11-22 12:38:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `aid` varchar(10) COLLATE utf8_bin NOT NULL,
  `apasswd` char(10) COLLATE utf8_bin DEFAULT NULL,
  `aname` char(4) COLLATE utf8_bin DEFAULT NULL,
  `asex` char(1) COLLATE utf8_bin DEFAULT NULL,
  `acsrq` date DEFAULT NULL,
  `anum` char(11) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1997000001', '123001', '靳伟才', '男', '1997-05-03', '16621664334');
INSERT INTO `admin` VALUES ('1997000002', '123002', '文雅惠', '女', '1997-02-22', '18299208231');
INSERT INTO `admin` VALUES ('1997000003', '123003', '杜美华', '女', '1997-03-25', '18105874368');
INSERT INTO `admin` VALUES ('1997000004', '123004', '钦清韵', '女', '1997-12-16', '13106209396');
INSERT INTO `admin` VALUES ('1997000005', '123005', '宰荌荌', '女', '1997-05-02', '18235188553');

-- ----------------------------
-- Table structure for `charge`
-- ----------------------------
DROP TABLE IF EXISTS `charge`;
CREATE TABLE `charge` (
  `cno` varchar(10) COLLATE utf8_bin NOT NULL,
  `uid` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `wno` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `aid` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `ccount` double(4,1) DEFAULT NULL,
  `cprice` double(4,1) DEFAULT NULL,
  `csfrq` date DEFAULT NULL,
  PRIMARY KEY (`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of charge
-- ----------------------------
INSERT INTO `charge` VALUES ('01', '19930001', '01', '1997000001', '80.0', '656.0', '2023-12-27');
INSERT INTO `charge` VALUES ('02', '19930002', '01', '1997000001', '93.0', '762.6', '2023-09-01');
INSERT INTO `charge` VALUES ('03', '19930003', '01', '1997000001', '67.0', '576.2', '2023-06-21');
INSERT INTO `charge` VALUES ('04', '19930004', '01', '1997000001', '55.0', '451.0', '2023-04-27');
INSERT INTO `charge` VALUES ('05', '19930005', '01', '1997000002', '79.0', '647.8', '2023-02-24');
INSERT INTO `charge` VALUES ('06', '20010001', '02', '1997000002', '102.0', '754.8', '2023-04-25');
INSERT INTO `charge` VALUES ('07', '20010002', '02', '1997000002', '111.0', '821.4', '2023-12-23');
INSERT INTO `charge` VALUES ('08', '20010003', '02', '1997000002', '135.0', '999.0', '2023-05-20');
INSERT INTO `charge` VALUES ('09', '20010004', '02', '1997000003', '127.0', '939.8', '2023-03-20');
INSERT INTO `charge` VALUES ('10', '20010005', '02', '1997000003', '108.0', '799.2', '2023-05-09');
INSERT INTO `charge` VALUES ('11', '20020001', '03', '1997000003', '10.0', '63.0', '2023-02-21');
INSERT INTO `charge` VALUES ('12', '20020002', '03', '1997000003', '8.0', '50.4', '2023-01-01');
INSERT INTO `charge` VALUES ('13', '20020003', '03', '1997000004', '6.0', '37.8', '2023-06-02');
INSERT INTO `charge` VALUES ('14', '20020004', '03', '1997000004', '4.0', '25.2', '2023-04-11');
INSERT INTO `charge` VALUES ('15', '20020005', '03', '1997000004', '12.0', '75.6', '2023-02-19');
INSERT INTO `charge` VALUES ('16', '20030001', '03', '1997000004', '5.0', '31.5', '2023-08-04');
INSERT INTO `charge` VALUES ('17', '20030002', '03', '1997000005', '7.0', '44.1', '2023-02-28');
INSERT INTO `charge` VALUES ('18', '20030003', '03', '1997000005', '5.0', '31.5', '2023-07-17');
INSERT INTO `charge` VALUES ('19', '20030004', '03', '1997000005', '6.0', '37.8', '2023-03-20');
INSERT INTO `charge` VALUES ('20', '20030005', '03', '1997000005', '8.0', '50.4', '2023-08-19');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` varchar(10) COLLATE utf8_bin NOT NULL,
  `uname` char(4) COLLATE utf8_bin DEFAULT NULL,
  `usex` char(1) COLLATE utf8_bin DEFAULT NULL,
  `unum` char(11) COLLATE utf8_bin DEFAULT NULL,
  `uadd` char(15) COLLATE utf8_bin DEFAULT NULL,
  `ucsrq` date DEFAULT NULL,
  `unote` char(10) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('19990001', '钦永宁', '男', '14983012300', '浙江柳州有限公司', '1999-08-16', null);
INSERT INTO `user` VALUES ('19990002', '项博实', '男', '16640574651', '浙江黄山有限公司', '1999-04-18', null);
INSERT INTO `user` VALUES ('19990003', '怀向雪', '女', '13229519275', '浙江松原有限公司', '1999-04-12', null);
INSERT INTO `user` VALUES ('19990004', '苏良平', '男', '13649686168', '浙江松原有限公司', '1999-03-11', null);
INSERT INTO `user` VALUES ('19990005', '包晴霞', '女', '15132626794', '浙江广安有限公司', '1999-07-14', null);
INSERT INTO `user` VALUES ('20010001', '充嘉祯', '男', '18876849968', '浙江青岛工厂', '2001-03-16', null);
INSERT INTO `user` VALUES ('20010002', '禄歌韵', '女', '15750277149', '浙江临汾工厂', '2001-01-16', null);
INSERT INTO `user` VALUES ('20010003', '闾丘英睿', '男', '18279524543', '浙江德宏工厂', '2001-09-20', null);
INSERT INTO `user` VALUES ('20010004', '储飞鸣', '男', '18008099493', '浙江信阳工厂', '2001-10-21', null);
INSERT INTO `user` VALUES ('20010005', '宁学名', '男', '17118957828', '浙江四平工厂', '2001-06-11', null);
INSERT INTO `user` VALUES ('20020001', '韩以彤', '女', '15323765890', '浙江定西小区', '2002-07-08', null);
INSERT INTO `user` VALUES ('20020002', '胡清心', '女', '13046198182', '浙江湘西小区', '2002-04-25', null);
INSERT INTO `user` VALUES ('20020003', '冉俊晤', '男', '14725507421', '浙江扬州小区', '2002-01-19', null);
INSERT INTO `user` VALUES ('20020004', '罗明志', '男', '18054938488', '浙江红河小区', '2002-03-16', null);
INSERT INTO `user` VALUES ('20020005', '段元纬', '男', '15681941576', '浙江红河小区', '2002-01-28', null);
INSERT INTO `user` VALUES ('20030001', '姬涵蓄', '男', '18874626051', '浙江玉林小区', '2003-09-18', null);
INSERT INTO `user` VALUES ('20030002', '亓官智敏', '女', '15338301414', '浙江池州小区', '2003-09-01', null);
INSERT INTO `user` VALUES ('20030003', '邴飞文', '男', '17185742620', '浙江张掖小区', '2003-02-18', null);
INSERT INTO `user` VALUES ('20030004', '暴雅素', '女', '18059081068', '浙江郴州小区', '2003-06-14', null);
INSERT INTO `user` VALUES ('20030005', '秦力强', '男', '17539659946', '浙江南通小区', '2003-06-21', null);

-- ----------------------------
-- Table structure for `waterprice`
-- ----------------------------
DROP TABLE IF EXISTS `waterprice`;
CREATE TABLE `waterprice` (
  `wno` varchar(10) COLLATE utf8_bin NOT NULL,
  `wtype` char(4) COLLATE utf8_bin DEFAULT NULL,
  `wunit` char(4) COLLATE utf8_bin DEFAULT NULL,
  `wprice` double(4,1) DEFAULT NULL,
  `wnote` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`wno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of waterprice
-- ----------------------------
INSERT INTO `waterprice` VALUES ('01', '商业用水', '吨', '8.2', null);
INSERT INTO `waterprice` VALUES ('02', '工业用水', '吨', '7.4', null);
INSERT INTO `waterprice` VALUES ('03', '居民用水', '吨', '6.3', null);
